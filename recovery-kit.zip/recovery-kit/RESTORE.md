# 现网 10 分钟预报系统 · 灾难恢复手册

快照时间：2026-10-23（账本快照 46 条）。本包只覆盖**现网**预报线（主 bot + Bark 推送 + 胜率追踪）。
影子 v1/v2/v3、微信桥、其他项目**不在本包范围**，见文末「丢了不可恢复」。

## 本包文件 → 恢复目标路径

记 `GOAL = ~/workspace/goals/tradingview-binance-indicator-monitoring-with-wecom-alerts`，
`HF = $GOAL/hidden_files`。

| 本包内路径 | 放回路径 |
|---|---|
| `hidden_files/event_10min_bot.py` | `$HF/event_10min_bot.py`（主脚本） |
| `hidden_files/mf_features.py`、`hidden_files/mf_features_v2.py` | `$HF/` 同名（主脚本的特征依赖） |
| `hidden_files/event_bot.py` | `$HF/event_bot.py`（主脚本 import 其 `queue_wechat`，缺了主脚本起不来；微信已停用，该函数现为惰性保留） |
| `hidden_files/lightgbm_10min.txt` | `$HF/`（主模型 LightGBM） |
| `hidden_files/lr_10min.pkl` | `$HF/`（备用 LR 模型，含 scaler） |
| `hidden_files/model_10min_meta.json` | `$HF/`（特征名单/参数/阈值 0.55/0.45 的权威记录） |
| `hidden_files/train_10min_models.py` | `$HF/`（重训脚本） |
| `hidden_files/mf_data_1m/FEAT3_BTCUSDT.npz`、`FEAT3_ETHUSDT.npz` | `$HF/mf_data_1m/`（重训输入：350 天特征数据） |
| `hidden_files/live_winrate_watch.py` | `$HF/`（结算/胜率脚本） |
| `hidden_files/live-alerts.jsonl` | `$HF/`（实盘账本，历史胜率的唯一依据） |
| `hidden_files/event_10min_bot_state.json` | `$HF/`（4 小时同向去重状态） |
| `hidden_files/winrate-reported-30.flag` | `$HF/`（防止胜率日报重复报告） |
| `custom.bark-push/bin/bark_send.py` | `~/workspace/custom-connectors/custom.bark-push/bin/bark_send.py`（Bark 发送脚本） |

**本包不含任何密钥**：Bark key 不在包里（见步骤 3）；微信 session 不在包里（微信已停用，不需要）。

## 恢复步骤

### 步骤 1：环境与 Python 依赖

- Python 3.12.3（现网在用版本）。
- 按现网实际版本安装（脚本 import 核实：主脚本用 numpy/pandas/lightgbm，训练与 LR 备用模型用 scikit-learn）：

```bash
pip install "numpy==1.26.4" "pandas==2.1.4" "lightgbm==4.7.0" "scikit-learn==1.9.1"
```

  版本要对齐：`lr_10min.pkl` 是 pickle，scikit-learn 大版本不一致可能加载失败；
  LightGBM 模型是文本格式，跨版本相对宽容。
- 行情数据运行时从币安公开接口实时拉取（脚本内 `api/v3/klines`），**不需要任何 API key**，不需要本地历史数据即可跑现网。

### 步骤 2：放回文件

按上表把文件复制回原路径（目录不存在先 `mkdir -p`）。注意两处硬编码路径：

- `train_10min_models.py` 里 `HF = "/home/hatch/workspace/goals/tradingview-binance-indicator-monitoring-with-wecom-alerts/hidden_files"` 是写死的绝对路径；若新环境家目录不是 `/home/hatch`，必须改这一行。
- `event_10min_bot.py` 用脚本所在目录定位模型（相对安全），但 Bark 脚本路径写的是
  `~/workspace/custom-connectors/custom.bark-push/bin/bark_send.py`，所以 Bark 脚本必须放在这个位置。
- `bark_send.py` 依赖平台提供的 `/opt/muse/skills/custom-connector-setup/bin/dynamic_credentials.py`
  （新 Muse 环境自带；若该文件不存在，先走步骤 3 的连接器重建流程，它会恢复这套机制）。

### 步骤 3：Bark 推送（key 必须用户本人重新录入）

Bark key 只存在于 Secure Vault，**不可读回、不在本包内**，这是有意设计。

1. 用户打开 iPhone 上的 Bark App，查看自己的设备 key。
2. 由用户经 Secure Vault 录入页重新录入，重建自定义连接器 `custom.bark-push`：
   - host：`api.day.app`
   - placement：`url_path_segment:/{}`（key 作为 URL 路径段注入）
3. 把本包的 `bark_send.py` 放回 `~/workspace/custom-connectors/custom.bark-push/bin/`。
4. 验证：`python3 ~/workspace/custom-connectors/custom.bark-push/bin/bark_send.py "恢复测试" "Bark 通道测试"`，
   返回 JSON 且 code 200、iPhone 收到推送即成功。
   （技术坑：surrogate 必须字面替换进 URL、不能 percent-encoding，脚本内已处理，勿改。）

### 步骤 4：重建两个 cron

owner 均为 `goal:tradingview-binance-indicator-monitoring-with-wecom-alerts`，投递到主聊天
（若主聊天 ID 已变，换成新主聊天 ID）。

**① `event-10min-forecast-bot`** — interval 每 5 分钟，时区 Asia/Shanghai，标题「10分钟事件合约预报机器人」。正文：

> 10 分钟事件合约预报巡检（只预报、不交易）。
>
> 步骤：
> 1. 运行 `/usr/bin/python3 ~/workspace/goals/tradingview-binance-indicator-monitoring-with-wecom-alerts/hidden_files/event_10min_bot.py`，输出 JSON。脚本计算 BTCUSDT/ETHUSDT 未来 10 分钟上涨概率；概率 ≥0.55 预报看涨、≤0.45 预报看跌，中间弃权；同标的同方向 4 小时去重开启（用户 2026-10-18 21:42 要求恢复），同方向告警冷却 4 小时后才可再次预报。alerts 非空即为新预报。脚本只经 Bark 推送到用户 iPhone（无配额限制；输出中每条 forecast 带 bark_ok 字段）。微信通道已于 2026-10-22 经用户拍板停用：脚本不再写微信 outbox（wechat_file 恒为 null），微信桥 serve 已停，不要查微信送达。
> 2. 送达判定：forecast.bark_ok=true 即 Bark 已送达，无需补推；bark_ok=false 时在 final message 里如实标注，由主 agent 决定是否在 Muse 聊天里补推。
> 3. 你的 final message 写：`alerts: [...]`（逐条：预报时间（本轮巡检的 CST 时间，精确到分钟）/标的/方向/上涨概率/核心指标值/bark_ok），以及 `status` 摘要。不要编造送达状态，以脚本输出为准。无 alerts 时 final message 只写 status，不要打扰用户。
> 4. 不要做交易，不要改脚本参数和阈值，不要直接给用户发微信（微信桥已停用）。
>
> 说明：模型期望胜率约 0.566（walk-forward 六折重估的诚实口径，0.60~0.65 的单次切分数字不再引用），未计手续费，不构成交易建议。

**② `live-winrate-watch`** — daily 每天 09:09，时区 Asia/Shanghai，标题「实盘胜率追踪（n≥30 报告）」。正文：

> 实盘胜率追踪（10 分钟预报 bot）。每天跑一次，只在有结论时打扰用户。
>
> 步骤：
> 1. 运行 `python3 ~/workspace/goals/tradingview-binance-indicator-monitoring-with-wecom-alerts/hidden_files/live_winrate_watch.py`，输出 JSON（n_total/n_settled/wins/win_rate）。
> 2. 如果脚本报错或输出解析失败：final message 只写 status 说明检查失败，不要编造数字。
> 3. 如果 n_settled ≥ 30 且 `~/workspace/goals/tradingview-binance-indicator-monitoring-with-wecom-alerts/hidden_files/winrate-reported-30.flag` 不存在：在主聊天报告一次真实水位（中文、简短直接）：已结算 n_settled 条、命中 wins、胜率 win_rate；对比回测期望 0.60~0.65 给一句诚实结论；说明未计手续费、不构成交易建议。报告后写入该 flag 文件（内容为报告日期），避免每天重复报告。
> 4. 如果 n_settled < 30 或 flag 已存在：final message 只写 status（如"n_settled=X/30，未到阈值"），不要打扰用户。
>
> 注意：ledger 从 2026-10-18 21:42 起记录（含 4 小时去重后的实盘预报）；不要回算 ledger 之前的条目。

### 步骤 5：验证恢复成功

1. 手动跑一次主脚本：
   `/usr/bin/python3 $HF/event_10min_bot.py`
   应输出 JSON：模型字段为 `gbm`（说明主模型加载成功；若显示 LR 降级，先查 lightgbm 是否装好）、
   `alerts` 可为空（概率落在 0.45–0.55 弃权区是正常状态，不是故障）。
2. 对账本：`python3 $HF/live_winrate_watch.py` 输出的 `n_total` 应等于
   `wc -l $HF/live-alerts.jsonl`（快照时 46；恢复时以包内实际条数为准），
   且 `win_rate` 应约 0.609（46 条口径，快照时点数值，仅供对账参考）。
3. Bark 测试推送到达 iPhone（步骤 3 第 4 点）。
4. 两个 cron 处于启用状态、能看到下一次运行时间；等一个 5 分钟周期，确认巡检自动跑了一轮。

### 步骤 6：如果模型文件也丢了（重训路径）

本包已含训练输入 `mf_data_1m/FEAT3_{BTCUSDT,ETHUSDT}.npz`（350 天、双标的、31 个特征，
与 `model_10min_meta.json` 的 feature_names 对齐），所以即使模型文件丢失也能原样重训：

1. 确认 npz 已放回 `$HF/mf_data_1m/`，且训练脚本里的 `HF` 路径与实际一致。
2. 运行 `python3 $HF/train_10min_models.py`：它先用最后 15% 时间顺序数据 early-stopping 定轮数，
   再全量 refit，重新生成 `lightgbm_10min.txt`、`lr_10min.pkl`、`model_10min_meta.json`。
   参数（num_leaves=15、min_child=1000、lr=0.05、seed=42、deterministic）写死在脚本里，可复现。
3. 重训后跑步骤 5 验证。

若连 npz 也丢了：原始 1 分钟 K 线可从币安公开归档 `data.binance.vision`（spot monthly/daily klines）
重新下载，再重建特征 npz。但**特征重建脚本（feat_v3.py 及其上游）不在本包内**，届时需要按
`model_10min_meta.json` 里的 31 个特征名单重新实现特征工程——这是本包已知的一个缺口。

## 丢了不可恢复（如本包本身也丢失）

- **实盘账本 `live-alerts.jsonl`**：历史预报与胜率轨迹只此一份（在本包内），包丢了历史即清零，
  只能从恢复之日起重新记账。本包就是它的备份，**请把本 zip 另存一份到 Muse 之外**（如 iPhone 文件/网盘）。
- **影子三线**（v1 全组合 / v2 规则门控 / v3 精选）：脚本、模型、账本均不在本包，按用户口径只保现网。
- **Bark key**：不在包内，只能由用户从 Bark App 查看后重新录入（步骤 3）。
- **微信桥登录态**：不在包内；微信通道已停用，不影响现网。
- Muse 的记忆、其他目标与项目文件：不在本包范围。
